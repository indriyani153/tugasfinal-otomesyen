class LoginData:
    username = 'admin@gmail.com'
    password = 'admin123'