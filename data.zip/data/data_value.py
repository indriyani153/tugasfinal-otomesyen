
class EnterValue:
    value = 'indriy'