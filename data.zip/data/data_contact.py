
class ContactData:
    name = 'abcd'
    email = 'abcd@gmail.com'
    address = 'Depok'
    mobile = '08123456789'

    

