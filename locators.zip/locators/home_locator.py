
class HomeLocator:
    login_button = 'Btn6'
    enter_value_button = 'Btn1'
    contactus_button = 'Btn2'

    