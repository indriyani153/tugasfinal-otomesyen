
class ValueLocator:
    enter_value = 'com.code2lead.kwad:id/Et1'
    btn_submit = 'com.code2lead.kwad:id/Btn1'
    preview = 'com.code2lead.kwad:id/Tv1'