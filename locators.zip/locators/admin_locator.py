
class AdminLocator:
    text_enter_admin = '//android.widget.TextView[@text="Enter Admin"]'