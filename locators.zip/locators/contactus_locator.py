
class ContactLocator:
    input_name = 'com.code2lead.kwad:id/Et2'
    input_email = 'com.code2lead.kwad:id/Et3'
    input_address = 'com.code2lead.kwad:id/Et6'
    input_mobileno = 'com.code2lead.kwad:id/Et7'
    click_submit = 'com.code2lead.kwad:id/Btn2'

    check_name = 'com.code2lead.kwad:id/Tv2'
    check_email = 'com.code2lead.kwad:id/Tv7'
    check_address = 'com.code2lead.kwad:id/Tv5'
    check_mobile = 'com.code2lead.kwad:id/Tv6'