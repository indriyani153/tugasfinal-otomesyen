
class LoginLocator:
    username = 'com.code2lead.kwad:id/Et4'
    password = 'com.code2lead.kwad:id/Et5'
    submit = 'com.code2lead.kwad:id/Btn3'

